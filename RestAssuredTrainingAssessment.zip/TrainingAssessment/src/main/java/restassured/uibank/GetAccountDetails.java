package restassured.uibank;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetAccountDetails extends RestAssuredBase {

	@Test(dependsOnMethods = { "restassured.uibank.LoginUiBank.login" })
	public void getAccountDetails() {

		RestAssured.baseURI = "https://uibank-api.azurewebsites.net/api";

		Response response = RestAssured.given().header("authorization", id)
				.queryParams("filter[where][userId]", "620f1e0b8932d4005f2a887a").get("accounts");

		response.prettyPrint();
		System.err.println(response.statusCode());

	}
}
