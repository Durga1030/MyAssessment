package restassured.uibank;

public class RestAssuredBase {
	
	public static String id = "";

}
