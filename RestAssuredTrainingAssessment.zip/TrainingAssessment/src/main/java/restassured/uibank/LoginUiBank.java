package restassured.uibank;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class LoginUiBank extends RestAssuredBase {

	@Test
	public void login() {

		RestAssured.baseURI = "https://uibank-api.azurewebsites.net/api";
		Response response = RestAssured.given().contentType(ContentType.JSON)
				.body("{\r\n" + "  \"username\": \"dbagya\",\r\n" + "  \"password\": \"U!b@nk#123\"\r\n" + "}")
				.post("users/login");

		response.prettyPrint();

		JsonPath path = response.jsonPath();

		id = path.get("id");

		System.err.println(id);
		System.out.println(response.statusCode());

	}

}
