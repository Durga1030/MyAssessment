package restassured.uibank;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class AccountVerification extends RestAssuredBase {

	@Test(dependsOnMethods = { "restassured.uibank.LoginUiBank.login" })
	public void verifyaccount() {

		RestAssured.baseURI = "https://uibank-api.azurewebsites.net/api/accounts";

		Response response = RestAssured.given().queryParams("filter[where][userId]", "620f1e0b8932d4005f2a887a")
				.header("authorization", id).get();

		JsonPath path = response.jsonPath();
		String object = path.get("friendlyName").toString();
		if (object.contains("dk_test")) {
			System.out.println("account created succesfully");
		}

		System.err.println(response.statusCode());
		System.out.println(object);
		System.err.println(response.statusCode());
	}

}
