package restassured.uibank;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class AccountCreation extends RestAssuredBase {

	@Test(dependsOnMethods = {"restassured.uibank.LoginUiBank.login" })
	public void createaccount() {

		RestAssured.baseURI = "https://uibank-api.azurewebsites.net/api/accounts";

		Response response = RestAssured.given().header("authorization", id).contentType(ContentType.JSON)
				.body("" + "{\"friendlyName\":\"dk_test\",\"type\":\"savings\",\"userId\":\"620f1e0b8932d4005f2a887a\",\"balance\":100,\"accountNumber\":48615973}")
				.post();

		response.prettyPrint();
		System.err.println(response.statusCode());
	}

}
